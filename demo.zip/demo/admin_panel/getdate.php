<?php
echo "<script>alert('hii');</script>";
exit;
?>