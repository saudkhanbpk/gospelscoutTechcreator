<?php

define("HOST", "db663107335.db.1and1.com");

// Database user
define("DBUSER", "dbo663107335");

// Database password
define("PASS", "Ww@123456");

// Database name
define("DB", "db663107335");

// Database Error - User Message
define("DB_MSG_ERROR", 'Could not connect!<br />Please contact the site\'s administrator.');

############## Make the mysql connection ###########

$conn = mysql_connect(HOST, DBUSER, PASS) or die(DB_MSG_ERROR);

$db = mysql_select_db(DB) or die(DB_MSG_ERROR);



if($_POST['value'] && $_POST['value1'] && $_POST['value2'])
{
$query = mysql_query("
  SELECT * 
  FROM patient_add 
  WHERE surname ='".$_POST['value']."' AND other_surname ='".$_POST['value1']."' AND  first_name ='".$_POST['value2']."'
");

while ($data = mysql_fetch_array($query)) {

  echo '
  							<b>ADDRESS :</b>'.$data["address"].'</br>
							
							<b>POPULATION :</b>'.$data["population"].'</br>
							
							<b>TELEPHONE :</b>'.$data["telephone"].'</br>
							
							<b>DNI :</b>'.$data["dni"].'</br>
							
							<b>MUTUAL :</b>'.$data["payment_type"].'</br>
							
							<b>NOTE :</b>'.$data["note"].'</br>';

echo '<div style="margin-left: 106%;border: 1px solid black;margin-top: -120px;height: 233px;width: 263px;">
	<table id="div">
		<tr>
			<td >'.$data["surname"].', '.$data["first_name"].'</td>
		</tr>
	</table> </div>';
}

}

else if($_POST['value'] && $_POST['value1'])
{

$query = mysql_query("
  SELECT * 
  FROM patient_add 
  WHERE surname ='".$_POST['value']."' AND other_surname ='".$_POST['value1']."'
");

while ($data = mysql_fetch_array($query)) {

  echo '
  							<b>ADDRESS :</b>'.$data["address"].'</br>
							
							<b>POPULATION :</b>'.$data["population"].'</br>
							
							<b>TELEPHONE :</b>'.$data["telephone"].'</br>
							
							<b>DNI :</b>'.$data["dni"].'</br>
							
							<b>MUTUAL :</b>'.$data["payment_type"].'</br>
							
							<b>NOTE :</b>'.$data["note"].'</br>';

echo '<div style="margin-left: 106%;border: 1px solid black;margin-top: -120px;height: 233px;width: 263px;">
	<table id="div">
		<tr>
			<td >'.$data["surname"].', '.$data["first_name"].'</td>
		</tr>
	</table> </div>';
}
}

else if($_POST['value1'] && $_POST['value2'])
{

$query = mysql_query("
  SELECT * 
  FROM patient_add 
  WHERE other_surname ='".$_POST['value1']."' AND first_name ='".$_POST['value2']."'
");

while ($data = mysql_fetch_array($query)) {

  echo '
  							<b>ADDRESS :</b>'.$data["address"].'</br>
							
							<b>POPULATION :</b>'.$data["population"].'</br>
							
							<b>TELEPHONE :</b>'.$data["telephone"].'</br>
							
							<b>DNI :</b>'.$data["dni"].'</br>
							
							<b>MUTUAL :</b>'.$data["payment_type"].'</br>
							
							<b>NOTE :</b>'.$data["note"].'</br>';

echo '<div style="margin-left: 106%;border: 1px solid black;margin-top: -120px;height: 233px;width: 263px;">
	<table id="div">
		<tr>
			<td >'.$data["surname"].', '.$data["first_name"].'</td>
		</tr>
	</table> </div>';
}
}

else if($_POST['value'] && $_POST['value2'])
{

$query = mysql_query("
  SELECT * 
  FROM patient_add 
  WHERE surname ='".$_POST['value']."' AND first_name ='".$_POST['value2']."'
");

while ($data = mysql_fetch_array($query)) {

  echo '
  							<b>ADDRESS :</b>'.$data["address"].'</br>
							
							<b>POPULATION :</b>'.$data["population"].'</br>
							
							<b>TELEPHONE :</b>'.$data["telephone"].'</br>
							
							<b>DNI :</b>'.$data["dni"].'</br>
							
							<b>MUTUAL :</b>'.$data["payment_type"].'</br>
							
							<b>NOTE :</b>'.$data["note"].'</br>';

echo '<div style="margin-left: 106%;border: 1px solid black;margin-top: -120px;height: 233px;width: 263px;">
	<table id="div">
		<tr>
			<td >'.$data["surname"].', '.$data["first_name"].'</td>
		</tr>
	</table> </div>';
}
}

else if($_POST['value'] || $_POST['value1'] || $_POST['value2'])
{

$query = mysql_query("
  SELECT * 
  FROM patient_add 
  WHERE surname ='".$_POST['value']."' OR other_surname ='".$_POST['value1']."' OR first_name ='".$_POST['value2']."'
");

while ($data = mysql_fetch_array($query)) {

  echo '
  							<b>ADDRESS :</b>'.$data["address"].'</br>
							
							<b>POPULATION :</b>'.$data["population"].'</br>
							
							<b>TELEPHONE :</b>'.$data["telephone"].'</br>
							
							<b>DNI :</b>'.$data["dni"].'</br>
							
							<b>MUTUAL :</b>'.$data["payment_type"].'</br>
							
							<b>NOTE :</b>'.$data["note"].'</br>';

echo '<div style="margin-left: 106%;border: 1px solid black;margin-top: -120px;height: 233px;width: 263px;">
	<table id="div">
		<tr>
			<td >'.$data["surname"].', '.$data["first_name"].'</td>
		</tr>
	</table> </div>';
}
}
?>