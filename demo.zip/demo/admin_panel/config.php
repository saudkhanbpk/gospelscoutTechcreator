<?php
session_start();
$con=mysql_connect('localhost','root','');
mysql_select_db('db663107335',$con);
?>

