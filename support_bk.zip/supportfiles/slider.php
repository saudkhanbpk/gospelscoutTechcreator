<div class="container">
        <div class="row">
            <div class="col-md-6 mt-5 "><br><br>
                <p class="head-pur">GOSPELSCOUT</p><br>
                <h1>Connect with<br>
                    top Gospel Artists<br>
                    And Musicians</h1><br><br>
                <p>Find the perfect performer for your event. Explore <br> gospel music like never before.</p><br>
                <div class="d-flex" style="gap: 12px;">
                    <button class="btn  btn-primary" style="border-radius: 20px; 
                    background-color:#9549AD ;
                    border: #9549AD;">Request A Demo</button><br>
                    <button class="btn btn-outline" style="border-radius: 20px;  border: #9549AD;">Browse
                        Artist</button>
                </div>
            </div>
            <div class="col-md-6 ontainer-fluid py-3 mt-5 ">
            <img class="img-fluid" class="img-fluid img-1" src="supportfiles/image/Component1.png" alt="" width="100%"
                height="1">


                <!-- <img class="img-fluid" class="img-fluid" src="image/Vector3.jpg" alt="" width="447.5px"
                                    height= "492px"
                                    flex-shrink= "0">
                                     -->
            </div>
        </div>
    </div>