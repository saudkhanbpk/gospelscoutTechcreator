
<div class="">
	<div class="container">
    	<div class="col-lg-12 col-md-12 col-sm-12 text-center">
        	<ul class="ul1">
            <li><a href="<?php echo URL;?>views/termsandcondition.php">Terms</a></li>
            <li><a href="<?php echo URL;?>views/contact_us.php">Contact</a></li>
            <li><a href="<?php echo URL;?>views/help.php">Help</a></li>
            <li><a href="<?php echo URL;?>views/copyright.php">Copyrights</a></li>
            <li><a href="<?php echo URL;?>views/aboutus.php">About</a></li>
            <li><a href="<?php echo URL;?>views/privacy.php" style="border:none;">Privacy</a></li>
            </ul>
        </div>
    </div>
</div>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    
    <!--<script src="js/jquery.js"></script>-->
  </body>
</html>