<?php
/*********************************************
One Hour Delivery  - Config file
Date - 14-March-2016 04:59 
**********************************************/

define('URL',"http://choicesrehab.org/gospel1/");
define('HTTP_SERVER',"http://choicesrehab.org/gospel1/");

/**********************Include Loader files***********************/
require_once "functions.php";
require_once "database.php";
$obj = new Database();

require_once "session.php";
$objsession = new Session();

define('PROJECT_NAME','Gospel Scout');
define('PROJECT_ADMIN_TITLE','Gospel Scout Administrator');