<?php
//db details
$dbHost = 'db651933262.db.1and1.com';
$dbUsername = 'dbo651933262';
$dbPassword = 'Gg@123456';
$dbName = 'db651933262';

//Connect and select the database
$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

require_once "session.php";
$objsession = new Session();

?>