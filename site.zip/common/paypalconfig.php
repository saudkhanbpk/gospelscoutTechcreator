<?php 

// Set sandbox (test mode) to true/false.
$sandbox = TRUE;

// Set PayPal API version and credentials.
$api_version = '85.0';
$api_endpoint = 'https://api-3t.sandbox.paypal.com/nvp';
$api_username = 'seller_smit_api1.gmail.com';
$api_password = '1400335007';
$api_signature = 'AFcWxV21C7fd0v3bYYYRCpSSRl31AmNoOqgzVFaJb-UgfJH0EXDrv9QV';

?>