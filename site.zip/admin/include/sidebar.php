<div class="collapse navbar-collapse navbar-ex1-collapse" id="top">
                <ul class="nav navbar-nav side-nav">
                    <li>
                        <a class="active" href="<?php echo HTTP_SERVER;?>views/dashboard.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
                    </li>
					<li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#cat"><i class="fa fa-fw fa-arrows-v"></i> Manage User <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="cat" class="collapse">
                            <li>
                                <a href="<?php echo HTTP_SERVER;?>views/viewusers.php"><i class="fa fa-fw fa-desktop"></i> Active User</a>
                            </li>
                            <li>
                                <a href="<?php echo HTTP_SERVER;?>views/viewdeactiveusers.php"><i class="fa fa-fw fa-desktop"></i> Deactive User</a>
                            </li>
                        </ul>
                    </li> 
					<li>
                        <a href="<?php echo HTTP_SERVER;?>views/content_data.php"><i class="fa fa-fw fa-desktop"></i> Registration Content </a>
                    </li> 
					<!--<li>
                        <a href="<?php echo HTTP_SERVER;?>views/main_banner.php"><i class="fa fa-fw fa-desktop"></i> Manage Main Page Banner </a>
                    </li>-->
					<li>
                        <a href="<?php echo HTTP_SERVER;?>views/viewgifts1.php"><i class="fa fa-fw fa-desktop"></i> Manage Church Gifts </a>
                    </li>                   
                    <li>
                        <a href="<?php echo HTTP_SERVER;?>views/viewgifts.php"><i class="fa fa-fw fa-desktop"></i> Manage Artist Talents</a>
                    </li>  
                    <li>
                        <a href="<?php echo HTTP_SERVER;?>views/viewevents.php"><i class="fa fa-fw fa-desktop"></i> Manage Event</a>
                    </li>                     
                    <li>
                        <a href="<?php echo HTTP_SERVER;?>views/viewcmspages.php"><i class="fa fa-fw fa-file-code-o"></i> Manage CMS</a>
                    </li>
                    
                    
                    <li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#cat"><i class="fa fa-fw fa-arrows-v"></i> Manage Booking <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="cat" class="collapse">
                            <li>
                                <a href="<?php echo HTTP_SERVER;?>views/artistbook.php">Artist Book</a>
                            </li>
                            <li>
                                <a href="<?php echo HTTP_SERVER;?>views/churchbook.php">Church Book</a>
                            </li>
                             <li>
                                <a href="<?php echo HTTP_SERVER;?>views/eventbook.php">Event Book</a>
                            </li>
                        </ul>
                    </li> 
                    <?php /*?><li>
                        <a href="javascript:;" data-toggle="collapse" data-target="#cat1"><i class="fa fa-fw fa-arrows-v"></i> Banner <i class="fa fa-fw fa-caret-down"></i></a>
                        <ul id="cat1" class="collapse">
                            <li>
                                <a href="<?php echo HTTP_SERVER;?>artistbanner">Artist Banner</a>
                            </li>
                            <li>
                                <a href="<?php echo HTTP_SERVER;?>churchbanner">Church Banner</a>
                            </li>
                             <li>
                                <a href="<?php echo HTTP_SERVER;?>eventbanner">Event Banner</a>
                            </li>
                        </ul>
                    </li> <?php */?>

                     
                    
                </ul>
            </div>