</div>
    <!-- /#wrapper -->

    <!-- jQuery -->
   
    <!-- Morris Charts JavaScript -->
    <?php /*?><script src="<?php echo PATH;?>js/plugins/morris/raphael.min.js"></script>
    <script src="<?php echo PATH;?>js/plugins/morris/morris.min.js"></script>
    <script src="<?php echo PATH;?>js/plugins/morris/morris-data.js"></script><?php */?>
</body>
</html>