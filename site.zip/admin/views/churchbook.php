<?php include('../include/header.php'); ?>
<?php
$cond="isActive IN(1) order by iBookID DESC";
$eventmaster = $obj->fetchRowAll('churchbooking',$cond);
$totaleventmaster = $obj->fetchNumOfRow('churchbooking',$cond);
?>
<script type="text/javascript">
	$(function () {
	$("#example1").DataTable({
		"lengthMenu": [5],
		"lengthChange": false,
		"searching": false,
		"pagingType": "numbers",
		"bJQueryUI": true,
		"sDom": '<"H"lfrp>t<"F"ip>',
		"info": false,
		"ordering": false,
		paging : $("#example1").find('tbody tr').length > 5
	});
});	
</script>
<div id="page-wrapper">
  <div class="container-fluid"> 
    <!-- Page Heading -->    
    <div class="row">
      <div class="col-lg-12">
        <h2>Church Booking</h2>
        <hr class="hrforrow" />
        
        <div class="">

<?php if($objsession->get('gs_message') != ""){?>
<span id="success-message"><?php echo $objsession->get('gs_message'); ?></span>
<?php $objsession->remove('gs_message');}?>
<?php
	if($totaleventmaster > 0){
		
		
?>
          <table class="table table-hover" id="example1">
            <thead>
              <tr>
                <th>Church Name</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email</th>
                <th>Address</th>
                <th>Price</th>
				<th>Donation For</th>
                <th>Book By</th>
                <th>Status</th>
               	<th>Action</th>
                
              </tr>
            </thead>
            <tbody>
			<?php	
				for($i=0;$i<count($eventmaster);$i++)
				{
					
					$cond1="iLoginID = '".$eventmaster[$i]['iLoginID']."'";
		$eventmaster1 = $obj->fetchRow('usermaster',$cond1);
				$cond2="iLoginID = '".$eventmaster[$i]['iRollID']."'";
		$eventmaster2 = $obj->fetchRow('usermaster',$cond2);
			$cond3="iEventID = '".$eventmaster[$i]['sType']."'";
		$eventmaster3 = $obj->fetchRow('eventtypes',$cond3);  
		

	
					//$img = explode(',',$eventmaster[$i]['sMultiImage']);
					
            ?>
              <tr>
                <td><?php if($eventmaster1['sUserName'] != ''){echo $eventmaster1['sUserName'];}else{echo '---';}?></td>
              <td><?php echo $eventmaster[$i]['sFirstName'];?></td>   
                 <td><?php echo $eventmaster[$i]['sLastName'];?></td>  
                 <td><?php echo $eventmaster[$i]['eEmailID'];?></td>  
                 <td><?php echo $eventmaster[$i]['sAddress'];?></td>  
                   <td><?php  echo "$". $eventmaster[$i]['iAmount'];?></td> 
                    <td><?php  if($eventmaster[$i]['donation'] != ''){echo  $eventmaster[$i]['donation'];}else{echo '---';}?></td>  
              <td><?php if($eventmaster2['sUserName'] != ""){ echo $eventmaster2['sUserName'];}else{echo '---';}?></td>
                <td><a href="<?php echo HTTP_SERVER;?>views/churchbook.php?bookIDS=<?php echo $eventmaster[$i]['iBookID'];?>&amp;satus=<?php  echo $eventmaster[$i]['sStatus']; ?>"><?php echo $eventmaster[$i]['sStatus'];?></a></td>              
                <td>
                    <a href="<?php echo HTTP_SERVER;?>views/churchbook.php?bookID=<?php echo $eventmaster[$i]['iBookID'];?>" title="Delete" onClick="return confirm('Are you sure want to delete?');"><i class="fa fa-fw fa-remove"></i></a></td>
              </tr>  
            <?php } ?>            
            </tbody>
          </table>
<?php }else{ ?>
<span class="recordnotfound">Event not found.</span>
<?php } ?>
        </div>
      </div>
    </div>
    <!-- /.row --> 
    
  </div>
  <!-- /.container-fluid --> 
</div>
<?php
if(isset($_GET['bookIDS'])){

if($_GET['satus']=="Pending"){
		$field = array('sStatus');
		$value = array('Completed');
		
		if($obj->update($field, $value, "iBookID = ".$_GET['bookIDS'],'churchbooking') == true){
			$objsession->set('gs_message','Church Status Update Sucessfully.');	
			redirect(HTTP_SERVER."churchbook");    
		}
}
else {
		$field = array('sStatus');
		$value = array('Pending');	
			if($obj->update($field, $value, "iBookID = ".$_GET['bookIDS'],'churchbooking') == true){
			$objsession->set('gs_message','Church Status Update Sucessfully.');	
			redirect(HTTP_SERVER."churchbook");  
		}}
}



if(isset($_GET['bookID'])){

		$field = array('isActive');
		$value = array(0);
		
		if($obj->update($field, $value, "iBookID = ".$_GET['bookID'],'churchbooking') == true){
			$objsession->set('gs_message','Church successfully deleted.');	
			redirect(HTTP_SERVER."churchbook");    
		}
}
?>
<?php include('../include/footer.php'); ?>
